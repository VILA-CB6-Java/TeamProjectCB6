package com.cb6.project.examactionsservice;

public class Grade {
	private Integer grade;
	
	public Grade() {}
	
	public Grade(Integer grade) {
		this.grade=grade;
	}

	public Integer getGrade() {
		return grade;
	}

	public void setGrade(Integer grade) {
		this.grade = grade;
	}
	
	
}
