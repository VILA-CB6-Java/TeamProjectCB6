﻿1. import as existing maven projects

2. Με το sql dumb δημιουργούμε τη βάση δεδομένων. Ανοίγουμε βάση δεδομένων με username: user και password: test

3. ανοιχτή βάση και μετά run as java application με τη σειρά 
    α) NetflixEurekaNamingServerApplication
    β) Τα υπόλοιπα services και τέλος... 
    γ) NetflixZuulApiGatewayServerApplication

4. Στο φάκελο που βρίσκεται το front εκτελούμε την εντολή ng serve (αφού πρώτα έχουμε εγκαταστήσει την angular 7)

5. Στο url https://localhost:4200 τρέχει η εφαρμογή μας (ελπίζουμε)!